# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/foreman/sources/llvm/examples/Kaleidoscope/Chapter8/toy.cpp" "/home/foreman/build/llvm/examples/Kaleidoscope/Chapter8/CMakeFiles/Kaleidoscope-Ch8.dir/toy.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "GTEST_HAS_RTTI=0"
  "LLVM_BUILD_GLOBAL_ISEL"
  "_GNU_SOURCE"
  "__STDC_CONSTANT_MACROS"
  "__STDC_FORMAT_MACROS"
  "__STDC_LIMIT_MACROS"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "examples/Kaleidoscope/Chapter8"
  "/home/foreman/sources/llvm/examples/Kaleidoscope/Chapter8"
  "include"
  "/home/foreman/sources/llvm/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/foreman/build/llvm/lib/Demangle/CMakeFiles/LLVMDemangle.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Support/CMakeFiles/LLVMSupport.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/TableGen/CMakeFiles/LLVMTableGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/IR/CMakeFiles/LLVMCore.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/IRReader/CMakeFiles/LLVMIRReader.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/CMakeFiles/LLVMCodeGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/SelectionDAG/CMakeFiles/LLVMSelectionDAG.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/AsmPrinter/CMakeFiles/LLVMAsmPrinter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/MIRParser/CMakeFiles/LLVMMIRParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/GlobalISel/CMakeFiles/LLVMGlobalISel.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Bitcode/Reader/CMakeFiles/LLVMBitReader.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Bitcode/Writer/CMakeFiles/LLVMBitWriter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Utils/CMakeFiles/LLVMTransformUtils.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Instrumentation/CMakeFiles/LLVMInstrumentation.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/InstCombine/CMakeFiles/LLVMInstCombine.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Scalar/CMakeFiles/LLVMScalarOpts.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/IPO/CMakeFiles/LLVMipo.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Vectorize/CMakeFiles/LLVMVectorize.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/ObjCARC/CMakeFiles/LLVMObjCARCOpts.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Coroutines/CMakeFiles/LLVMCoroutines.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Linker/CMakeFiles/LLVMLinker.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Analysis/CMakeFiles/LLVMAnalysis.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/LTO/CMakeFiles/LLVMLTO.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/CMakeFiles/LLVMMC.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/MCParser/CMakeFiles/LLVMMCParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/MCDisassembler/CMakeFiles/LLVMMCDisassembler.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Object/CMakeFiles/LLVMObject.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ObjectYAML/CMakeFiles/LLVMObjectYAML.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Option/CMakeFiles/LLVMOption.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/DWARF/CMakeFiles/LLVMDebugInfoDWARF.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/MSF/CMakeFiles/LLVMDebugInfoMSF.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/CodeView/CMakeFiles/LLVMDebugInfoCodeView.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/PDB/CMakeFiles/LLVMDebugInfoPDB.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/Symbolize/CMakeFiles/LLVMSymbolize.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/CMakeFiles/LLVMExecutionEngine.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/Interpreter/CMakeFiles/LLVMInterpreter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/MCJIT/CMakeFiles/LLVMMCJIT.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/Orc/CMakeFiles/LLVMOrcJIT.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/RuntimeDyld/CMakeFiles/LLVMRuntimeDyld.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/CMakeFiles/LLVMTarget.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/CMakeFiles/LLVMX86CodeGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/AsmParser/CMakeFiles/LLVMX86AsmParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/Disassembler/CMakeFiles/LLVMX86Disassembler.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/InstPrinter/CMakeFiles/LLVMX86AsmPrinter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/MCTargetDesc/CMakeFiles/LLVMX86Desc.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/TargetInfo/CMakeFiles/LLVMX86Info.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/Utils/CMakeFiles/LLVMX86Utils.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/CMakeFiles/LLVMAMDGPUCodeGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/AsmParser/CMakeFiles/LLVMAMDGPUAsmParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/InstPrinter/CMakeFiles/LLVMAMDGPUAsmPrinter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/Disassembler/CMakeFiles/LLVMAMDGPUDisassembler.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/TargetInfo/CMakeFiles/LLVMAMDGPUInfo.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/MCTargetDesc/CMakeFiles/LLVMAMDGPUDesc.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/AMDGPU/Utils/CMakeFiles/LLVMAMDGPUUtils.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/AsmParser/CMakeFiles/LLVMAsmParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/LineEditor/CMakeFiles/LLVMLineEditor.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ProfileData/CMakeFiles/LLVMProfileData.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ProfileData/Coverage/CMakeFiles/LLVMCoverage.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Passes/CMakeFiles/LLVMPasses.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/LibDriver/CMakeFiles/LLVMLibDriver.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/XRay/CMakeFiles/LLVMXRay.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/tools/lto/CMakeFiles/LTO.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/tools/llvm-shlib/CMakeFiles/LLVM.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
