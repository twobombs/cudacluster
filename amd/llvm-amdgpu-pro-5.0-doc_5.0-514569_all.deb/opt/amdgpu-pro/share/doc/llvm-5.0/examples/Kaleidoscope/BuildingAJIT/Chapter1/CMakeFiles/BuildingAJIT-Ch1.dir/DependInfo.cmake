# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/foreman/sources/llvm/examples/Kaleidoscope/BuildingAJIT/Chapter1/toy.cpp" "/home/foreman/build/llvm/examples/Kaleidoscope/BuildingAJIT/Chapter1/CMakeFiles/BuildingAJIT-Ch1.dir/toy.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "GTEST_HAS_RTTI=0"
  "LLVM_BUILD_GLOBAL_ISEL"
  "_GNU_SOURCE"
  "__STDC_CONSTANT_MACROS"
  "__STDC_FORMAT_MACROS"
  "__STDC_LIMIT_MACROS"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "examples/Kaleidoscope/BuildingAJIT/Chapter1"
  "/home/foreman/sources/llvm/examples/Kaleidoscope/BuildingAJIT/Chapter1"
  "include"
  "/home/foreman/sources/llvm/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/foreman/build/llvm/lib/Analysis/CMakeFiles/LLVMAnalysis.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/IR/CMakeFiles/LLVMCore.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/CMakeFiles/LLVMExecutionEngine.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/InstCombine/CMakeFiles/LLVMInstCombine.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Object/CMakeFiles/LLVMObject.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ExecutionEngine/RuntimeDyld/CMakeFiles/LLVMRuntimeDyld.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Scalar/CMakeFiles/LLVMScalarOpts.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Support/CMakeFiles/LLVMSupport.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/CMakeFiles/LLVMX86CodeGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/InstPrinter/CMakeFiles/LLVMX86AsmPrinter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/AsmParser/CMakeFiles/LLVMX86AsmParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/MCTargetDesc/CMakeFiles/LLVMX86Desc.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/TargetInfo/CMakeFiles/LLVMX86Info.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/Disassembler/CMakeFiles/LLVMX86Disassembler.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/X86/Utils/CMakeFiles/LLVMX86Utils.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/AsmPrinter/CMakeFiles/LLVMAsmPrinter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/CodeView/CMakeFiles/LLVMDebugInfoCodeView.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/DebugInfo/MSF/CMakeFiles/LLVMDebugInfoMSF.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/GlobalISel/CMakeFiles/LLVMGlobalISel.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/SelectionDAG/CMakeFiles/LLVMSelectionDAG.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/CodeGen/CMakeFiles/LLVMCodeGen.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Target/CMakeFiles/LLVMTarget.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Transforms/Utils/CMakeFiles/LLVMTransformUtils.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Bitcode/Writer/CMakeFiles/LLVMBitWriter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ProfileData/CMakeFiles/LLVMProfileData.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Bitcode/Reader/CMakeFiles/LLVMBitReader.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/MCParser/CMakeFiles/LLVMMCParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/MCDisassembler/CMakeFiles/LLVMMCDisassembler.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/CMakeFiles/LLVMMC.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Demangle/CMakeFiles/LLVMDemangle.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
