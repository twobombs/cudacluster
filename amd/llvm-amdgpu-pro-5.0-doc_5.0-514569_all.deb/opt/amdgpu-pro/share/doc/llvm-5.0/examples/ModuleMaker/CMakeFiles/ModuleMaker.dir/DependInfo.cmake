# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/foreman/sources/llvm/examples/ModuleMaker/ModuleMaker.cpp" "/home/foreman/build/llvm/examples/ModuleMaker/CMakeFiles/ModuleMaker.dir/ModuleMaker.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "GTEST_HAS_RTTI=0"
  "LLVM_BUILD_GLOBAL_ISEL"
  "_GNU_SOURCE"
  "__STDC_CONSTANT_MACROS"
  "__STDC_FORMAT_MACROS"
  "__STDC_LIMIT_MACROS"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "examples/ModuleMaker"
  "/home/foreman/sources/llvm/examples/ModuleMaker"
  "include"
  "/home/foreman/sources/llvm/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/foreman/build/llvm/lib/Bitcode/Writer/CMakeFiles/LLVMBitWriter.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/IR/CMakeFiles/LLVMCore.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Support/CMakeFiles/LLVMSupport.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Analysis/CMakeFiles/LLVMAnalysis.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Object/CMakeFiles/LLVMObject.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Bitcode/Reader/CMakeFiles/LLVMBitReader.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/MCParser/CMakeFiles/LLVMMCParser.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/MC/CMakeFiles/LLVMMC.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/ProfileData/CMakeFiles/LLVMProfileData.dir/DependInfo.cmake"
  "/home/foreman/build/llvm/lib/Demangle/CMakeFiles/LLVMDemangle.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
