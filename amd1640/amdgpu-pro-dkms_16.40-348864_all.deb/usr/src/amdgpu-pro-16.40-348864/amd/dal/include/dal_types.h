/*
 * Copyright 2012-15 Advanced Micro Devices, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE COPYRIGHT HOLDER(S) OR AUTHOR(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Authors: AMD
 *
 */

#ifndef __DAL_TYPES_H__
#define __DAL_TYPES_H__

#include "signal_types.h"
#include "dc_types.h"

struct dal_logger;
struct dc_bios;

enum dce_version {
	DCE_VERSION_UNKNOWN = (-1),
#if defined(CONFIG_DRM_AMD_DAL_DCE8_0)
	DCE_VERSION_8_0,
#endif
#if defined(CONFIG_DRM_AMD_DAL_DCE10_0)
	DCE_VERSION_10_0,
#endif
#if defined(CONFIG_DRM_AMD_DAL_DCE11_0)
	DCE_VERSION_11_0,
#endif
#if defined(CONFIG_DRM_AMD_DAL_DCE11_2)
	DCE_VERSION_11_2,
#endif
	DCE_VERSION_MAX,
};

#endif /* __DAL_TYPES_H__ */
