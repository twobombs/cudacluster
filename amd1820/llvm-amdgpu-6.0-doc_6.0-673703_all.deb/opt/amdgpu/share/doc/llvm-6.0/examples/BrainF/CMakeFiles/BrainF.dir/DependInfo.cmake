# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/foreman/sources/llvm/examples/BrainF/BrainF.cpp" "/home/foreman/build/llvm/examples/BrainF/CMakeFiles/BrainF.dir/BrainF.cpp.o"
  "/home/foreman/sources/llvm/examples/BrainF/BrainFDriver.cpp" "/home/foreman/build/llvm/examples/BrainF/CMakeFiles/BrainF.dir/BrainFDriver.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "GTEST_HAS_RTTI=0"
  "_GNU_SOURCE"
  "__STDC_CONSTANT_MACROS"
  "__STDC_FORMAT_MACROS"
  "__STDC_LIMIT_MACROS"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "examples/BrainF"
  "/home/foreman/sources/llvm/examples/BrainF"
  "include"
  "/home/foreman/sources/llvm/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/foreman/build/llvm/tools/llvm-shlib/CMakeFiles/LLVM.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
